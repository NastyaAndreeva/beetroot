file = open("practice.txt", "w")

file.write("Hello everybody\n")
file.write("What's up?\n")
file.write("I like Python a lot <3\n")

file.close()