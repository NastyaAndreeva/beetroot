const obj1 = {
  name: "Nastya",
};

const str = JSON.stringify(obj1);

console.log(str);
